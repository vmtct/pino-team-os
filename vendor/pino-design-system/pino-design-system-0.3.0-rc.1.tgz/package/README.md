# @pino/design-system

## 0.3.0-rc.1 property contract candidate — PAP-1155

Portable `PropertySections`, `PropertyRow` and `PropertyEditor` now extend the existing frames. Current candidate exports point to `dist/0.3.0-rc.1`; old `dist/0.1.0` and `dist/0.2.0` artifacts remain byte-identical. PINO and LuuDo independently pin their release archives; this PR does not change either app.

`PropertySections` owns section/row DOM and a container-responsive grid. Drawer is always one column. Editing requires an explicit `canEdit`, `onCommit` AND `onSaved`; readonly is the default. `recordKey` isolates subjects and aborts the editor on subject change. Async adapters return `saved` with the actual saved value, `denied`, `conflict`, or `error`. Only confirmed success calls `onSaved`. The consumer owns data refresh, version/idempotency, server-side authorization and business atomicity; aborting a UI request does not promise that a server write was rolled back.

```tsx
import { PropertySections } from "@pino/design-system/react";
import "@pino/design-system/bo-tokens.css";
import "@pino/design-system/components.css";

<PropertySections
  recordKey={staff.id}
  surface="ho"
  fields={[
    { key: "name", label: "Họ tên", type: "text", readOnly: true },
    { key: "role", label: "Vai trò", type: "select", options: allowedRoles }
  ]}
  values={staff}
  sections={[{ id: "staff", label: "Thông tin Staff", fields: ["name", "role"] }]}
  canEdit={key => permissions.canEdit(key)}
  onCommit={(key, value, { signal }) => staffAdapter.commit(key, value, { signal })}
  onSaved={(key, value) => updateConfirmedStaff(key, value)}
/>
```

Use the same component with `variant="drawer"` inside `DrawerFrame`; do not copy a Detail grid into a Drawer or append a raw select after properties. The normal BO/HO layout and portal token context are owned by the component. Low-level `PropertyEditor` callers must key the editor by subject identity and supply a connected anchor; prefer `PropertySections` for this lifecycle.

Supported editors: text, textarea, number, currency, date, datetime-local (`datetime`), email, URL, select and boolean. Async relation search, multi-select/person/relation providers, history, business forms, registry and app routing remain owned by the existing TDD engine/consumer; this candidate does not pretend to be a complete portable schema engine. Unsupported metadata fails rather than silently inventing an editor.

Visual input: approved i5 BO registrations at `http://192.168.1.6:8799/playground.html#registrations`, live CSS SHA `ce278d894129794fb2919b79b8bf9519463671bd14323863dba3629a1e7cb841` (2026-10-29). Extraction keeps the property/editor grammar, while container-based adaptation, explicit focus handling and HO theme are tested candidate behavior. Full-shell/prototype visual parity and Founder golden approval are **pending**, not implied by passing geometry. The token source pins remain those of 0.1.0; the manifest distinguishes these from the newer property visual input.

Run `npm ci`, `npm run build:artifacts`, `npm run verify`, then `npx playwright install chromium` and `npm run test:browser`. Browser tests use only deterministic in-memory UI fixtures, never business APIs. Screenshots and geometry are emitted to `artifacts/pap1155`; they are review evidence, not Founder-approved goldens. `PAP1155_CHROMIUM` optionally selects a locally installed test browser; CI uses the pinned Playwright Chromium.

Release/adoption handoff: review this candidate, reconcile the prototype/package/consumer coverage matrix, then handle PINO bridge under PAP-1117 and LuuDo adoption under its own feature scope. No stable release, auto-upgrade, production or ACL authority is granted here.

## Historical 0.1.0 token package

One PINO-owned versioned CSS token source for PINO and LuuDo. Epic PAP-1114, package task PAP-1115.

Exports are generated directly from canonical i5 PINO BO and TOS sources with source and dist SHA in dist/0.1.0/manifest.json. All CSS scoped to operator surfaces, no global :root leakage. No domain CSS or React components in 0.1.0.

Consumers pin exact version/hash, upgrade independently after regression. Changes require version bump. Production remains manual. React Table/Drawer/Detail and TOS components are a separate future package slice.

## GitHub CI and portable reproducibility
Versioned source snapshots are stored in the snapshots folder, extracted from pinned canonical i5 PINO sources, with original path and hash for provenance. The verify-ci.py script checks reproducible CSS and absence of global/Guest/Website selectors in GitHub runners. On i5 verify.py additionally checks source drift. New source requires semver bump and both consumer regression.

## 0.2.0 portable component candidates (PAP-1118)
- New CSS export: components.css. Opt-in React export: react (DrawerFrame, DetailFrame, TableFrame; TosCard, TosButton, TosBottomNav).
- Peer dependency react 19. CSS uses PINO bo/tos semantic tokens. No Next.js, Core API or ACL imported. Existing PINO renderers are not yet replaced. Consumers must set the intended data-pino-ds host context, import bo/tos tokens and components.css, and perform their own E2E/CI. LuuDo static prototype remains on v0.1.0 until its own feature Jira migration.
- The 0.2.0 GitHub artifact exists; its availability does not imply PINO runtime adoption or full prototype parity. Current LuuDo app source pins and imports 0.2.0; the older static prototype 0.1.0 statement above is historical.
