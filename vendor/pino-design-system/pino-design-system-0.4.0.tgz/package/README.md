# @pino/design-system

One PINO-owned, versioned **presentation package** for PINO BO/HO/TOS and independently pinned LuuDo consumers. Epic PAP-1114. PINO's typed TDD registry/controller/router remains in pino-team-os under PAP-1067; domain/API/ACL remain with each consumer.

## 0.3.0 presentation contract

Exports: TableFrame, DrawerFrame, DetailFrame, PropertySections, PropertyRow, PropertyEditor, SingleSelect, PresentationState, TosCard, TosButton and TosBottomNav. Import scoped bo/tos tokens and components.css, then opt into data-pino-ds context. Frames accept ready/loading/empty/error/denied presentation; property editing requires explicit permission and confirmed async adapter callbacks.

The **existing approved HO Staff single-select** is reused unchanged in geometry/styling. Native browser/OS popup variation is allowed; search/multi/async are separate capabilities. Comparison tests use the immutable approved 0.3.0-rc.1 pin plus five viewport and narrow-container measurements. No second custom popup or TDD engine is introduced.

- [Full component contract and ownership](docs/component-contract.md)
- [Machine-readable coverage / prototype-field mapping](contracts/components.json), also exported as `@pino/design-system/contract.json`
- [Approved select source + measured baseline](contracts/approved-ho-select.json)

```tsx
import {PropertySections} from '@pino/design-system/react';
import '@pino/design-system/bo-tokens.css';
import '@pino/design-system/components.css';

<PropertySections recordKey={record.id} surface="ho"
  fields={[{key:'role',label:'Vai trò',type:'select',required:true,options:authorizedOptions}]}
  values={record} sections={[{id:'info',label:'Thông tin',fields:['role']}]}
  canEdit={key=>adapter.canEdit(key)}
  onCommit={(key,value,{signal})=>adapter.commitAndReadback(key,value,{signal})}
  onSaved={(key,value)=>applyConfirmedValue(key,value)}/>
```

The adapter supplies saved/denied/conflict/error outcomes. The package has no fetch, session, permission policy, business persistence or module registry. Consumers supply only authorized data and preserve their own mutation/version/readback contracts. Legacy relation/person/multi-value editors are not silently replaced by text inputs.

## Verify and release

`npm ci && npm run build:artifacts && npm run verify`; install the pinned browser with `npx playwright install chromium`, then `npm run test:browser`. Python 3 is needed for immutable legacy-token verification. `PAP1155_CHROMIUM` may select an installed local Chromium; CI uses the pinned Playwright browser. Artifacts contain actual screenshots and metrics, not invented acceptance.

Old 0.1.0, 0.2.0 and 0.3.0-rc.1 releases stay byte-identical. New consumers pin the exact archive/version/hash and upgrade independently. 0.3.0 source/CI, merge/tag/release, consumer staging and Founder acceptance are tracked separately in Jira. No npm-publication or Production deployment is implied.

## Historical releases

0.1.0 (PAP-1115): 48 BO/HO + 95 TOS semantic tokens extracted from pinned canonical i5 sources. 0.2.0 (PAP-1118): portable TDD frames and TOS components, release source e37dbdeeb447e814f0ba1274251e61053632ec84. 0.3.0-rc.1 (PAP-1155): editable properties candidate, source 3fd9c166b72b82bdf872a29519cd92217d96dc77; adopted and approved in HO Staff PAP-1117. Older README statements that PINO never adopted the package or that all LuuDo code is still on CSS-only 0.1.0 are superseded by those scoped receipts.

## 0.4.0 additive spatial-editor presentation - PAP-1686 / PNR-TV

Import SpatialEditorFrame and SpatialVertexHandle from @pino/design-system/spatial-editor and component-owned styling from @pino/design-system/spatial-editor.css. All House-compatible visual styles are bounded by the SpatialEditorFrame root attribute data-pds-spatial-editor. PINO Team owns all spatial geometry, tool state, PAP-651 motion, Core/Center ACL, persistence, and HO route/Detail tab. Existing v0.3.0 release artifacts remain immutable. A new Team consumer must pin the exact v0.4.0 archive and prove CI/G3 before FSG7.
