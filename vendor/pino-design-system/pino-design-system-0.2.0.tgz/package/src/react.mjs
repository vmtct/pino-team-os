"use client";
import { createElement as h, useEffect, useId, useRef } from "react";

/**
 * Portable PINO operator primitives. Business API, auth and routes are supplied
 * by each consumer. Based on approved PINO TDD shell and TOS semantic contracts.
 * The original feature renderers remain source authority until explicitly adopted.
 */
function useDialogFocus(ref, onClose, enabled) {
  useEffect(() => {
    if (!enabled || !ref.current) return;
    const panel = ref.current;
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const formerOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const focusable = () => [...panel.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')].filter(el => el instanceof HTMLElement && el.getClientRects().length);
    (focusable()[0] || panel).focus();
    const keydown = event => {
      if (event.key === "Escape") { event.preventDefault(); onClose(); return; }
      if (event.key !== "Tab") return;
      const items = focusable(), first = items[0], last = items.at(-1);
      if (!first || !last) { event.preventDefault(); panel.focus(); return; }
      if (event.shiftKey && (document.activeElement === first || !panel.contains(document.activeElement))) {
        event.preventDefault(); last.focus();
      } else if (!event.shiftKey && (document.activeElement === last || !panel.contains(document.activeElement))) {
        event.preventDefault(); first.focus();
      }
    };
    document.addEventListener("keydown", keydown);
    return () => {
      document.removeEventListener("keydown", keydown);
      document.body.style.overflow = formerOverflow;
      if (previous?.isConnected) previous.focus();
    };
  }, [ref, onClose, enabled]);
}

export function DrawerFrame({ title, path = "", onClose, footer, children, open = true }) {
  const panel = useRef(null);
  const titleId = useId();
  useDialogFocus(panel, onClose, open);
  if (!open) return null;
  return h("div", { className: "pds-drawer-layer", "data-pino-ds": "bo", "data-pds-component": "drawer" },
    h("div", { className: "pds-drawer-scrim", "aria-hidden": "true", onMouseDown: e => { if (e.target === e.currentTarget) onClose(); } }),
    h("aside", { className: "pds-drawer", ref: panel, role: "dialog", "aria-modal": "true", "aria-labelledby": titleId, tabIndex: -1 },
      h("div", { className: "pds-drawer-top" },
        h("div", { className: "pds-drawer-heading" }, path && h("small", null, path), h("h2", { id: titleId }, title)),
        h("button", { className: "pds-icon-button", type: "button", "aria-label": "Đóng", onClick: onClose }, "×")),
      h("div", { className: "pds-drawer-body" }, children),
      footer != null && h("div", { className: "pds-drawer-footer" }, footer)));
}

export function DetailFrame({ title, subtitle, tabs = [], selected, onSelect, onBack, actions, children }) {
  if (new Set(tabs.map(t => t.id)).size !== tabs.length) throw Error("Duplicate Detail tabs");
  const id = useId();
  const active = tabs.find(t => t.id === selected) || tabs[0];
  const tabId = tab => id + "-tab-" + tab.id;
  const panelId = id + "-panel";
  const advance = (e, i) => {
    const n = tabs.length;
    if (!n) return;
    let idx;
    if (e.key === "ArrowRight") idx = (i + 1) % n;
    else if (e.key === "ArrowLeft") idx = (i + n - 1) % n;
    else if (e.key === "Home") idx = 0;
    else if (e.key === "End") idx = n - 1;
    else return;
    e.preventDefault();
    onSelect?.(tabs[idx].id);
    document.getElementById(tabId(tabs[idx]))?.focus();
  };
  return h("section", { className: "pds-detail", "data-pino-ds": "bo", "data-pds-component": "detail", "aria-label": title },
    h("header", { className: "pds-detail-hero" },
      onBack && h("button", { className: "pds-icon-button", type: "button", onClick: onBack, "aria-label": "Về bảng" }, "←"),
      h("div", { className: "pds-detail-identity" }, h("h1", null, title), subtitle && h("p", null, subtitle)),
      actions),
    h("div", { className: "pds-detail-tabs", role: "tablist", "aria-label": "Chi tiết" },
      tabs.map((t, i) => h("button", {
        key: t.id, id: tabId(t), type: "button", role: "tab",
        "aria-selected": active?.id === t.id, "aria-controls": panelId,
        tabIndex: active?.id === t.id ? 0 : -1,
        onClick: () => onSelect?.(t.id), onKeyDown: e => advance(e, i)
      }, t.label))),
    h("div", { className: "pds-detail-panel", role: "tabpanel", id: panelId,
      "aria-labelledby": active ? tabId(active) : undefined, tabIndex: 0 }, children));
}

export function TableFrame({ caption, columns, rows, rowKey, empty = "Không có dữ liệu", onRowSelect }) {
  if (!Array.isArray(columns) || !Array.isArray(rows)) throw Error("TableFrame expects columns and rows");
  const count = columns.length;
  if (!count) throw Error("TableFrame requires at least one column");
  return h("div", { className: "pds-table-scroll", "data-pino-ds": "bo", "data-pds-component": "table" },
    h("table", { className: "pds-table" }, h("caption", { className: "pds-sr-only" }, caption),
      h("thead", null, h("tr", null, columns.map(c => h("th", { key: c.key, scope: "col" }, c.label)))),
      h("tbody", null, rows.length ? rows.map((r, idx) => {
        const key = rowKey ? rowKey(r) : idx;
        const events = onRowSelect ? {
          tabIndex: 0, onClick: () => onRowSelect(r),
          onKeyDown: e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onRowSelect(r); } }
        } : {};
        return h("tr", { key, ...events, "data-pds-row": key },
          columns.map(c => h("td", { key: c.key }, c.render ? c.render(r) : r[c.key])));
      }) : h("tr", null, h("td", { colSpan: count, className: "pds-empty" }, empty)))));
}

export function TosCard({ children, className = "" }) {
  return h("article", { className: ["pds-tos-card", className].filter(Boolean).join(" "), "data-pino-ds": "tos", "data-pds-component": "tos-card" }, children);
}

export function TosButton({ children, type = "button", variant = "primary", ...props }) {
  if (!["primary", "secondary", "quiet", "destructive"].includes(variant)) throw Error("Unknown TOS button variant");
  return h("button", { ...props, type, className: ["pds-tos-button", "pds-tos-button-" + variant, props.className].filter(Boolean).join(" "), "data-pino-ds": "tos", "data-pds-component": "tos-button" }, children);
}

export function TosBottomNav({ items, active, onChange, label = "TOS" }) {
  if (!Array.isArray(items) || items.length > 5) throw Error("TOS bottom nav supports at most five items");
  return h("nav", { className: "pds-tos-bottom-nav", "aria-label": label, "data-pino-ds": "tos", "data-pds-component": "tos-bottom-nav" },
    items.map(item => h("button", { key: item.id, type: "button", "aria-current": active === item.id ? "page" : undefined, onClick: () => onChange(item.id) },
      item.icon && h("span", { "aria-hidden": "true", className: "pds-tos-nav-icon" }, item.icon),
      h("span", null, item.label))));
}
