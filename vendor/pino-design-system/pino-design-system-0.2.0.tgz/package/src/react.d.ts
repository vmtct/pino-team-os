import type { ReactNode, MouseEventHandler, ButtonHTMLAttributes } from "react";
export interface DetailTab { readonly id: string; readonly label: string }
export interface DetailFrameProps {
  title: string; subtitle?: string; tabs?: readonly DetailTab[];
  selected?: string; onSelect?: (id: string) => void; onBack?: () => void;
  actions?: ReactNode; children: ReactNode;
}
export declare function DetailFrame(props: DetailFrameProps): ReactNode;
export declare function DrawerFrame(props: {
  title: string; path?: string; onClose: () => void;
  footer?: ReactNode; children: ReactNode; open?: boolean;
}): ReactNode;
export interface TableColumn<Row> {
  key: string; label: string; render?: (row: Row) => ReactNode;
}
export declare function TableFrame<Row>(props: {
  caption: string; columns: readonly TableColumn<Row>[];
  rows: readonly Row[]; rowKey?: (row: Row) => string | number;
  empty?: string; onRowSelect?: (row: Row) => void;
}): ReactNode;
export declare function TosCard(props: { children: ReactNode; className?: string }): ReactNode;
export declare function TosButton(props: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "quiet" | "destructive";
}): ReactNode;
export interface TosNavItem { readonly id: string; readonly label: string; readonly icon?: ReactNode }
export declare function TosBottomNav(props: {
  items: readonly TosNavItem[]; active: string;
  onChange: (id: string) => void; label?: string;
}): ReactNode;
