import test from "node:test";
import assert from "node:assert/strict";
import { createElement as h } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { DrawerFrame, DetailFrame, TableFrame, TosCard, TosButton, TosBottomNav } from "../dist/0.2.0/react.mjs";

test("TDD Drawer owns accessible dialog and head/footer", () => {
  const html = renderToStaticMarkup(h(DrawerFrame, {title:"Nhân sự", path:"BO / Staff", onClose:()=>{}, footer:h("button",null,"Lưu")}, h("p",null,"Content")));
  assert.match(html, /role="dialog"/);
  assert.match(html, /aria-modal="true"/);
  assert.match(html, /aria-labelledby=/);
  assert.match(html, /data-pds-component="drawer"/);
  assert.match(html, /BO \/ Staff/);
  assert.match(html, />Lưu</);
});
test("Detail tabs unique, semantic and first/last unconstrained", () => {
  const t=[{id:"overview",label:"Tổng quan"},{id:"rate",label:"Rate lương"},{id:"history",label:"Lịch sử"}];
  const html=renderToStaticMarkup(h(DetailFrame,{title:"Nhân viên A",tabs:t,selected:"rate",onSelect:()=>{}}, "Detail body"));
  assert.equal((html.match(/role="tab"/g)||[]).length,3);
  assert.match(html, /aria-selected="true"/);
  assert.match(html, /aria-controls=/);
  assert.match(html, /role="tabpanel"/);
  assert.throws(()=>renderToStaticMarkup(h(DetailFrame,{title:"Invalid",tabs:[t[0],t[0]]}, "x")),/Duplicate Detail tabs/);
});
test("Table columns are data-defined, no hard-coded prototype order",()=>{
  const html=renderToStaticMarkup(h(TableFrame,{caption:"Ca tuần",columns:[{key:"name",label:"Nhân sự"},{key:"day",label:"Ngày"}],rows:[{name:"Minh",day:"T4"}],rowKey:r=>r.name}));
  assert.match(html,/role="none"|<table/);
  assert.match(html, /<caption/);
  assert.match(html, /scope="col"/);
  assert.match(html, /Minh/);
  const empty=renderToStaticMarkup(h(TableFrame,{caption:"Trống",columns:[{key:"x",label:"X"}],rows:[]}));
  assert.match(empty,/colSpan="1"/);
});
test("TOS primitives preserve semantics, nav limit, status",()=>{
  const c=renderToStaticMarkup(h(TosCard,null,"Mở ca"));
  const b=renderToStaticMarkup(h(TosButton,{variant:"secondary"},"Tiếp tục"));
  const n=renderToStaticMarkup(h(TosBottomNav,{items:[{id:"shift",label:"Ca Làm",icon:"⏱"},{id:"kds",label:"Bếp"}],active:"shift",onChange:()=>{}}));
  assert.match(c,/data-pds-component="tos-card"/);
  assert.match(b,/type="button"/);
  assert.match(n,/aria-current="page"/);
  assert.match(n,/aria-label="TOS"/);
  assert.throws(()=>renderToStaticMarkup(h(TosBottomNav,{items:Array.from({length:6},(_,i)=>({id:String(i),label:String(i)})),active:"0",onChange:()=>{}})),/at most five/);
  assert.throws(()=>renderToStaticMarkup(h(TosButton,{variant:"unknown"},"x")),/Unknown TOS button/);
});
