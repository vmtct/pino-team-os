# Changelog

## 0.1.0 - 2026-10-28
- Initial scoped BO/HO and TOS canonical source-backed tokens.

## 0.2.0 — PAP-1118
- Portable Table/Drawer/Detail and TOS Card/Button/BottomNav React primitives and CSS classes; versioned source/hash manifest, strict no-App dependency, UI consumers opt in independently.
- 0.1.0 artifacts unchanged; shared React components are candidate building blocks, NOT adopted PINO runtime components yet.
