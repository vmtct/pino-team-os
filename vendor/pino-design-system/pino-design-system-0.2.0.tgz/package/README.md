# @pino/design-system v0.1.0

One PINO-owned versioned CSS token source for PINO and LuuDo. Epic PAP-1114, package task PAP-1115.

Exports are generated directly from canonical i5 PINO BO and TOS sources with source and dist SHA in dist/0.1.0/manifest.json. All CSS scoped to operator surfaces, no global :root leakage. No domain CSS or React components in 0.1.0.

Consumers pin exact version/hash, upgrade independently after regression. Changes require version bump. Production remains manual. React Table/Drawer/Detail and TOS components are a separate future package slice.

## GitHub CI and portable reproducibility
Versioned source snapshots are stored in the snapshots folder, extracted from pinned canonical i5 PINO sources, with original path and hash for provenance. The verify-ci.py script checks reproducible CSS and absence of global/Guest/Website selectors in GitHub runners. On i5 verify.py additionally checks source drift. New source requires semver bump and both consumer regression.

## 0.2.0 portable component candidates (PAP-1118)
- New CSS export: components.css. Opt-in React export: react (DrawerFrame, DetailFrame, TableFrame; TosCard, TosButton, TosBottomNav).
- Peer dependency react 19. CSS uses PINO bo/tos semantic tokens. No Next.js, Core API or ACL imported. Existing PINO renderers are not yet replaced. Consumers must set the intended data-pino-ds host context, import bo/tos tokens and components.css, and perform their own E2E/CI. LuuDo static prototype remains on v0.1.0 until its own feature Jira migration.
- Version 0.2.0 is a candidate; do not publish as stable or claim parity until CI and Founder/consumer acceptance.
