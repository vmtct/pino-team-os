import { readFileSync, writeFileSync, copyFileSync, mkdirSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { createHash } from "node:crypto";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const old = join(root, "dist", "0.1.0");
const dir = join(root, "dist", "0.2.0");
const sha = path => createHash("sha256").update(readFileSync(path)).digest("hex");
const read = path => readFileSync(path, "utf8");
const write = (path, text) => writeFileSync(path, text, "utf8");

mkdirSync(dir, {recursive: true});
const source = JSON.parse(read(join(old, "manifest.json")));
for (const name of ["bo-tokens.css", "tos-tokens.css"]) {
  write(join(dir, name), read(join(old, name)).replaceAll("v0.1.0", "v0.2.0").replaceAll(" 0.1.0 ", " 0.2.0 "));
}
for (const name of ["components.css", "react.mjs", "react.d.ts"]) {
  copyFileSync(join(root, "src", name), join(dir, name));
}
const files = ["bo-tokens.css", "tos-tokens.css", "components.css", "react.mjs", "react.d.ts"];
const components = ["components.css", "react.mjs", "react.d.ts"];
const manifest = {
  name: "@pino/design-system", version: "0.2.0", status: "PORTABLE_PRIMITIVES_CANDIDATE",
  sourceOwner: "PINO", sources: source.sources, exportedTokens: source.exportedTokens,
  dist: Object.fromEntries(files.map(name => [name, sha(join(dir, name))])),
  sourceFiles: Object.fromEntries(components.map(name => [name, sha(join(root, "src", name))])),
  jira: {epic: "PAP-1114", task: "PAP-1118"},
  boundaries: [
    "No Next.js app imports",
    "No business API, auth, or data logic",
    "No PINO runtime adoption yet",
    "LuuDo static prototype consumes CSS tokens v0.1.0 until separately updated"
  ]
};
write(join(dir, "manifest.json"), JSON.stringify(manifest, null, 2) + "\n");
console.log("BUILT @pino/design-system 0.2.0", manifest.dist);
