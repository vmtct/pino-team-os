from pathlib import Path
import hashlib,json,re
R=Path(__file__).resolve().parents[1]
V='0.2.0'
dist=R/'dist'/V
m=json.loads((dist/'manifest.json').read_text(encoding='utf-8'))
assert m['version']==V and m['name']=='@pino/design-system'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,want in m['dist'].items():
 assert h(dist/name)==want,name+' SHA mismatch'
for name,want in m['sourceFiles'].items():
 assert h(R/'src'/name)==want,name+' source mismatch'
 assert (R/'src'/name).read_bytes()==(dist/name).read_bytes()
css=(dist/'components.css').read_text(encoding='utf-8')
assert all(x in css for x in ('.pds-table','.pds-drawer','.pds-detail','.pds-tos-bottom-nav','.pds-tos-button'))
assert re.search(r'(?m)^\s*(body|:root|h1|table|button)\s*\{',css) is None,'Unscoped global CSS selector'
assert '@import' not in css and 'url(' not in css
assert '.pds-table td{box-sizing:border-box;height:var(--bo-table-row-height)}' in css
assert '.pds-tos-bottom-nav{box-sizing:border-box' in css
react=(dist/'react.mjs').read_text(encoding='utf-8')
assert 'next/' not in react and 'fetch(' not in react and 'localStorage' not in react
for fn in ('TableFrame','DrawerFrame','DetailFrame','TosCard','TosButton','TosBottomNav'):
 assert 'export function '+fn in react,fn
for name in ['bo-tokens.css','tos-tokens.css']:
 old=(R/'dist'/'0.1.0'/name).read_text(encoding='utf-8')
 expected=old.replace('v0.1.0','v0.2.0').replace(' 0.1.0 ', ' 0.2.0 ')
 assert (dist/name).read_text(encoding='utf-8')==expected,name
print('PORTABLE_PRIMITIVES_VERIFY_PASS',m['dist'])
