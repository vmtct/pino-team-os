#!/usr/bin/env python3
"""Check @pino/design-system pinned v0.1.0 build against authoritative PINO i5 source.
The default check does NOT write or mutate source/artifacts.
"""
from pathlib import Path
import hashlib,json,re,sys
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def extract(txt,prefix):
 m=re.search(r':root\s*\{',txt)
 if not m:raise RuntimeError('No root tokens')
 depth=1;j=m.end()
 while depth and j<len(txt):
  if txt[j]=='{':depth+=1
  if txt[j]=='}':depth-=1
  j+=1
 if depth:raise RuntimeError('Malformed CSS root')
 return {k:v.strip() for k,v in re.findall(r'(--[a-z0-9_-]+)\s*:\s*([^;]+);',txt[m.end():j-1]) if k.startswith(prefix)}
def render(data,scope,version):
 return '/* @pino/design-system '+version+' generated from authoritative PINO source. DO NOT EDIT. */\n'+scope+' {\n'+'\n'.join('  '+k+': '+v+';' for k,v in data.items())+'\n}\n'
def check():
 manifest_path=ROOT/'dist'/'0.1.0'/'manifest.json'
 m=json.loads(manifest_path.read_text(encoding='utf-8'))
 src=m['sources']
 defs=[
  ('bo-tokens.css','bo','--bo-',':where(body[data-app="bo"], body[data-app="ho"], [data-pino-ds="bo"])','boBaseSha256'),
  ('tos-tokens.css','tos','--tos-',':where(body[data-app="tos"], [data-pino-ds="tos"])','tosTokensSha256')
 ]
 for fn,name,prefix,scope,hashKey in defs:
  origin=Path(src[name]);want=src[hashKey]
  if not origin.is_file():raise RuntimeError('Missing source '+str(origin))
  actual=sha(origin)
  if actual!=want:raise RuntimeError('SOURCE DRIFT '+name+' expected '+want+' got '+actual+'; version bump and Founder reconciliation required')
  tokens=extract(origin.read_text(encoding='utf-8'),prefix)
  if len(tokens)!=m['exportedTokens'][name]:raise RuntimeError('Token count drift '+name)
  built=render(tokens,scope,m['version']).encode()
  dist=manifest_path.parent/fn
  if dist.read_text(encoding='utf-8')!=built.decode():raise RuntimeError('ARTIFACT DRIFT '+fn)
  if sha(dist)!=m['dist'][fn]:raise RuntimeError('Hash mismatch '+fn)
  if b':root' in built:raise RuntimeError('Global root leaked into package')
  print(fn,'OK',len(tokens),'tokens',sha(dist))
 print('CHECK PASS. Existing artifact reproducible; no writes.')
if __name__=='__main__':
 if len(sys.argv)>1:raise SystemExit('Read-only verification only; bump package version in a separate Jira change')
 check()
